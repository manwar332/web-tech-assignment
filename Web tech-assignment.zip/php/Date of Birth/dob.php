<html>
    <head><title>Date of Birth</title></head>
    <body>
        <table border="0">
            <tr>
                <td>Date of Birth : </td>
                <td><?php echo $_REQUEST['day']."/".$_REQUEST['month']."/".$_REQUEST['year'] ?></td>
            </tr>

        </table>
    </body>
</html>
