
<?php
$name=$_REQUEST['name'];
?>
<html>
    <head><title>Student Name</title></head>
    <body>
        <table border="0">
            <tr>
                <td>Name : </td>
                <td><?php echo $name ?></td>
            </tr>

        </table>
    </body>
</html>
