<?php
$gender=$_REQUEST['gender'];
?>
<html>
    <head><title>Gender</title></head>
    <body>
        <table border="0">
            <tr>
                <td>Gender : </td>
                <td><?php echo $gender ?></td>
            </tr>

        </table>
    </body>
</html>
