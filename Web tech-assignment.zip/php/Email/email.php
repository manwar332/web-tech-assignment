
<?php
$email=$_REQUEST['email'];
?>
<html>
    <head><title>Email</title></head>
    <body>
        <table border="0">
            <tr>
                <td>Email : </td>
                <td><?php echo $email ?></td>
            </tr>

        </table>
    </body>
</html>
