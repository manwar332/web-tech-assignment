
<?php
$bloodgroup=$_REQUEST['bloodgroup'];
?>
<html>
    <head><title>Blood Group</title></head>
    <body>
        <table border="0">
            <tr>
                <td>Blood Group : </td>
                <td><?php echo $bloodgroup ?></td>
            </tr>

        </table>
    </body>
</html>
